-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here

-- Berpindah antar window dengan Ctrl + h / j / k / l secara langsung
vim.keymap.set("n", "<C-h>", "<C-w>h", { desc = "Pindah ke window kiri" })
vim.keymap.set("n", "<C-j>", "<C-w>l", { desc = "Pindah ke window kanan" })
vim.keymap.set("n", "<C-k>", "<C-w>j", { desc = "Pindah ke window bawah" })
vim.keymap.set("n", "<C-l>", "<C-w>k", { desc = "Pindah ke window atas" })
