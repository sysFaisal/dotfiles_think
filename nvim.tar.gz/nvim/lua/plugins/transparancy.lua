return {
  {
    "folke/snacks.nvim",
    opts = function()
      -- Membuat area editor utama transparan
      vim.api.nvim_set_hl(0, "Normal", { bg = "none" })
      vim.api.nvim_set_hl(0, "NormalNC", { bg = "none" })
      vim.api.nvim_set_hl(0, "NormalFloat", { bg = "none" })
      vim.api.nvim_set_hl(0, "FloatBorder", { bg = "none" })

      vim.api.nvim_set_hl(0, "SnacksDashboardNormal", { bg = "none" })
      vim.api.nvim_set_hl(0, "SnacksDashboardHeader", { bg = "none" })
      vim.api.nvim_set_hl(0, "SnacksDashboardFooter", { bg = "none" })
      vim.api.nvim_set_hl(0, "SnacksDashboardDesc", { bg = "none" })
      vim.api.nvim_set_hl(0, "SnacksDashboardIcon", { bg = "none" })
      vim.api.nvim_set_hl(0, "SnacksDashboardKey", { bg = "none" })
      vim.api.nvim_set_hl(0, "SnacksDashboardDir", { bg = "none" })

      -- Mengatur agar sisi kiri (Neo-tree) tetap memiliki background solid (tidak transparan)
      vim.api.nvim_set_hl(0, "NeoTreeNormal", { bg = "#181825" })
      vim.api.nvim_set_hl(0, "NeoTreeNormalNC", { bg = "#181825" })
      vim.api.nvim_set_hl(0, "NeoTreeEndOfBuffer", { bg = "#181825", fg = "#181825" })
    end,
  },
}