return {
  "nvim-neo-tree/neo-tree.nvim",
  opts = {
    window = {
      position = "left",
      width = 30,
      -- Memaksa jendela Neo-tree menggunakan highlight group dengan background solid
      winhighlight = "Normal:NeoTreeNormal,NormalNC:NeoTreeNormalNC,SignColumn:NeoTreeSignColumn",
    },
  },
}